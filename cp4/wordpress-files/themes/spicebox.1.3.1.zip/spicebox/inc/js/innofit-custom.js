JotForm.init(function(){
      JotForm.highlightInputs = false;
	JotForm.clearFieldOnHide="disable";
    /*INIT-END*/
	});

   JotForm.prepareCalculationsOnTheFly([null,null,{"name":"submitForm","qid":"2","text":"Submit Feedback","type":"control_button"},{"name":"input3","qid":"3","text":"","type":"control_radio"},{"name":"clickTo","qid":"4","text":"Quick Feedback\nYour feedback is valuable to us.","type":"control_text"},{"name":"clickTo5","qid":"5","text":"Skip &amp; Deactive","type":"control_text"},{"description":"","name":"others","qid":"6","subLabel":"Your feedback means a lot to us","text":"Others","type":"control_textarea"},{"name":"typeA","qid":"7","text":"Type a question","type":"control_hidden"}]);
   setTimeout(function() {
JotForm.paymentExtrasOnTheFly([null,null,{"name":"submitForm","qid":"2","text":"Submit Feedback","type":"control_button"},{"name":"input3","qid":"3","text":"","type":"control_radio"},{"name":"clickTo","qid":"4","text":"Quick Feedback\nYour feedback is valuable to us.","type":"control_text"},{"name":"clickTo5","qid":"5","text":"Skip &amp; Deactive","type":"control_text"},{"description":"","name":"others","qid":"6","subLabel":"Your feedback means a lot to us","text":"Others","type":"control_textarea"},{"name":"typeA","qid":"7","text":"Type a question","type":"control_hidden"}]);}, 20); 