<?php
do_action('honeybee_footer_section_hook');?>	
</div>
<?php wp_footer();?>	
</body>
</html>